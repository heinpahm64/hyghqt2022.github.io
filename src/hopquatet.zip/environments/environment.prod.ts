export const environment = {
  production: true,
  apiIp: 'https://api.hoangyengroup.com'
};
